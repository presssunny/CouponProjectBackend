package com.sunny;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponProjectSunnySpringBoot3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
