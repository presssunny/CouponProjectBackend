package com.sunny.LogIn.Ex;

public class NoClientSessionException extends RuntimeException {
    public NoClientSessionException(String message) {
        super(message);
    }
}
