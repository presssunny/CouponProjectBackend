package com.sunny.LogIn.Ex;

public class NoPermissionToConnectException extends RuntimeException {
    public NoPermissionToConnectException(String message) {
    super(message);
    }
}
