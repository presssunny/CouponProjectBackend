package com.sunny.LogIn;

public record LoginCredentials(String email, String password, int type) {
}
