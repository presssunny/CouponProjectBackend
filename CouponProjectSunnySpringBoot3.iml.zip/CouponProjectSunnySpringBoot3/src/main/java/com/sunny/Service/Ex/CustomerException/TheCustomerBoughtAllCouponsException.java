package com.sunny.Service.Ex.CustomerException;

public class TheCustomerBoughtAllCouponsException extends RuntimeException{
    public TheCustomerBoughtAllCouponsException(String message) {
        super(message);
    }
}
